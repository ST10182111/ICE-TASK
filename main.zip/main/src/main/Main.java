
package main;
/**
 *
 * @ST10182111_RuhanPillay_IceTask1
 */
public class Main {

    
    public static void main(String[] args) {
       
        Bird brd = new Bird();
        System.out.println("Enter details for the bird:");
        brd.input();
        System.out.println("\nBird Details:");
        brd.output();

        
        Reptile rept = new Reptile();
        System.out.println("\nEnter details for the reptile:");
        rept.input();
        System.out.println("\nReptile Details:");
        rept.output();
    }  //end of method
    
}  //end of class

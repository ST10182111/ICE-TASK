
package main;
import java.util.Scanner;
/**
 *
 * @ST10182111_RuhanPillay_IceTask1
 */
public class Animal {    //parent/super class
    
    
    protected int IDtag;
    protected String species;

    
    
    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter ID tag: ");
        IDtag = scanner.nextInt();   //scanner to collect the users entry for animal ID
        scanner.nextLine(); 
        System.out.print("Enter species: ");
        species = scanner.nextLine(); //scanner to collect the users entry for animal species
    }  //end of method1

    
    
    
    public void output() {
        System.out.println("ID Tag: " + IDtag);
        System.out.println("Species: " + species);
    }  //end of method2
    
} //end of class

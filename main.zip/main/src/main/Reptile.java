
package main;
import java.util.Scanner;
/**
 *
 * @ST10182111_RuhanPillay_IceTask1
 */
public class Reptile extends Animal {           //child class
    
    private double bloodTemp;

    @Override
    public void input() {
        super.input();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter blood temperature: ");
        bloodTemp = scanner.nextDouble(); //scanner to collect the users entry for temperature
    } //end of method 1

    
    
    
    
    
    
    
    @Override
    public void output() {
        super.output();
        System.out.println("Blood Temperature: " + bloodTemp);
    } //end of method2
    
    
    
} //end of class

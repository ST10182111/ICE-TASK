
package main;
import java.util.Scanner;
/**
 *
 * @ST10182111_RuhanPillay_IceTask1
 */
public class Bird extends Animal {    //child class
    
    private int colour;

    @Override
    public void input() {    
        super.input();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter feather colour (1=grey, 2=white, 3=black): ");
        colour = scanner.nextInt();   //scanner to collect the users entry for feather colour
    }  //end of method1

    
    
    @Override
    public void output() {
        super.output();
        System.out.println("Feather Colour: " + colour);
    }  //end of method2
    
}  //end of class
